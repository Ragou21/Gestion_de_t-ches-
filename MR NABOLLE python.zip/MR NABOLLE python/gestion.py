import tkinter as tk
from tkinter import messagebox
import json
import os

# ==== CLASSE DE BASE POUR UNE TÂCHE ====

class Tache:
    def _init_(self, titre, description, responsable, date_limite, priorite, statut="À faire"):
        self.titre = titre
        self.description = description
        self.responsable = responsable
        self.date_limite = date_limite
        self.priorite = priorite
        self.statut = statut

    def afficher(self):
        return (f"Titre : {self.titre}\n"
                f"Description : {self.description}\n"
                f"Responsable : {self.responsable}\n"
                f"Date limite : {self.date_limite}\n"
                f"Priorité : {self.priorite}\n"
                f"Statut : {self.statut}\n"
                f"{'-'*40}")

    def to_dict(self):
        # Convertir la tâche en dictionnaire pour sauvegarde JSON
        return {
            "titre": self.titre,
            "description": self.description,
            "responsable": self.responsable,
            "date_limite": self.date_limite,
            "priorite": self.priorite,
            "statut": self.statut
        }

# ==== GESTION DE LA SAUVEGARDE JSON ====

def charger_taches():
    if os.path.exists("taches.json"):
        with open("taches.json", "r") as fichier:
            donnees = json.load(fichier)
            return [Tache(**t) for t in donnees]
    return []

def sauvegarder_taches():
    with open("taches.json", "w") as fichier:
        json.dump([t.to_dict() for t in liste_taches], fichier, indent=4)

# ==== LISTE GLOBALE DES TÂCHES CHARGÉES ====

liste_taches = charger_taches()

# ==== FONCTIONS PRINCIPALES ====

def ajouter_tache():
    titre = entry_titre.get().strip()
    description = entry_description.get().strip()
    responsable = entry_responsable.get().strip()
    date_limite = entry_date.get().strip()
    priorite = var_priorite.get()

    if titre and description and responsable and date_limite:
        tache = Tache(titre, description, responsable, date_limite, priorite)
        liste_taches.append(tache)
        sauvegarder_taches()
        messagebox.showinfo("Succès", "Tâche ajoutée avec succès.")
        afficher_taches()
    else:
        messagebox.showwarning("Champs manquants", "Veuillez remplir tous les champs.")

def afficher_taches():
    text_affichage.delete("1.0", tk.END)
    if not liste_taches:
        text_affichage.insert(tk.END, "Aucune tâche à afficher.\n")
    else:
        for t in liste_taches:
            text_affichage.insert(tk.END, t.afficher() + "\n")

def modifier_statut():
    titre = entry_titre_modif.get().strip()
    for t in liste_taches:
        if t.titre.lower() == titre.lower():
            nouveau_statut = var_statut.get()
            t.statut = nouveau_statut
            sauvegarder_taches()
            messagebox.showinfo("Modifié", "Statut mis à jour.")
            afficher_taches()
            return
    messagebox.showwarning("Introuvable", "Tâche non trouvée.")

def supprimer_tache():
    titre = entry_titre_suppr.get().strip()
    global liste_taches
    for t in liste_taches:
        if t.titre.lower() == titre.lower():
            liste_taches.remove(t)
            sauvegarder_taches()
            messagebox.showinfo("Supprimé", "Tâche supprimée.")
            afficher_taches()
            return
    messagebox.showwarning("Erreur", "Tâche non trouvée.")

# ==== INTERFACE GRAPHIQUE (TKINTER) ====

root = tk.Tk()
root.title("Planificateur de Tâches")
root.configure(bg="white")

# === Ajouter une tâche ===
frame_ajout = tk.Frame(root, bg="white")
frame_ajout.pack(pady=10)

tk.Label(frame_ajout, text="Titre :", bg="white").grid(row=0, column=0)
entry_titre = tk.Entry(frame_ajout)
entry_titre.grid(row=0, column=1)

tk.Label(frame_ajout, text="Description :", bg="white").grid(row=1, column=0)
entry_description = tk.Entry(frame_ajout)
entry_description.grid(row=1, column=1)

tk.Label(frame_ajout, text="Responsable :", bg="white").grid(row=2, column=0)
entry_responsable = tk.Entry(frame_ajout)
entry_responsable.grid(row=2, column=1)

tk.Label(frame_ajout, text="Date limite :", bg="white").grid(row=3, column=0)
entry_date = tk.Entry(frame_ajout)
entry_date.grid(row=3, column=1)

tk.Label(frame_ajout, text="Priorité :", bg="white").grid(row=4, column=0)
var_priorite = tk.StringVar(value="Moyenne")
tk.OptionMenu(frame_ajout, var_priorite, "Haute", "Moyenne", "Basse").grid(row=4, column=1)

tk.Button(frame_ajout, text="Ajouter Tâche", command=ajouter_tache, bg="#FFD700").grid(row=5, columnspan=2)

# === Afficher les tâches ===
frame_affichage = tk.Frame(root, bg="white")
frame_affichage.pack(pady=10)

tk.Label(frame_affichage, text="Liste des tâches :", bg="white").pack()
text_affichage = tk.Text(frame_affichage, height=12, width=60)
text_affichage.pack()

# === Modifier le statut ===
frame_modif = tk.Frame(root, bg="white")
frame_modif.pack(pady=10)

tk.Label(frame_modif, text="Titre à modifier :", bg="white").grid(row=0, column=0)
entry_titre_modif = tk.Entry(frame_modif)
entry_titre_modif.grid(row=0, column=1)

tk.Label(frame_modif, text="Nouveau Statut :", bg="white").grid(row=1, column=0)
var_statut = tk.StringVar(value="En cours")
tk.OptionMenu(frame_modif, var_statut, "À faire", "En cours", "Terminée").grid(row=1, column=1)

tk.Button(frame_modif, text="Modifier Statut", command=modifier_statut, bg="lightblue").grid(row=2, columnspan=2)

# === Supprimer une tâche ===
frame_suppr = tk.Frame(root, bg="white")
frame_suppr.pack(pady=10)

tk.Label(frame_suppr, text="Titre à supprimer :", bg="white").grid(row=0, column=0)
entry_titre_suppr = tk.Entry(frame_suppr)
entry_titre_suppr.grid(row=0, column=1)

tk.Button(frame_suppr, text="Supprimer Tâche", command=supprimer_tache, bg="red", fg="white").grid(row=1, columnspan=2)

# Affichage initial
afficher_taches()

# === Lancer l'application ===
root.mainloop()